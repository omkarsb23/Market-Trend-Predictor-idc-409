from nbtools import code, md

SETUP = '''
import sys, warnings
sys.path.insert(0, "..")                      # lets notebooks/ import config.py and src/
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import config
from src import db, features

# ---- one consistent look: validated categorical palette, thin marks, recessive grid ----
PAL = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, MUTED, GRID = "#0b0b0b", "#52514e", "#e1e0d9"
plt.rcParams.update({
    "figure.facecolor": "#fcfcfb", "axes.facecolor": "#fcfcfb", "savefig.facecolor": "#fcfcfb",
    "axes.prop_cycle": plt.cycler(color=PAL), "axes.edgecolor": "#c3c2b7", "axes.labelcolor": MUTED,
    "xtick.color": MUTED, "ytick.color": MUTED, "text.color": INK, "axes.titlecolor": INK,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.7, "axes.axisbelow": True,
    "axes.spines.top": False, "axes.spines.right": False, "axes.titleweight": "bold",
    "axes.titlesize": 11, "lines.linewidth": 1.6, "figure.dpi": 100, "legend.frameon": False,
})
DIVERGE = sns.blend_palette(["#2a78d6", "#f0efec", "#eb6834"], as_cmap=True)
pd.set_option("display.width", 150); pd.set_option("display.max_columns", 40)

MODE = config.resolve_mode(); P = config.get_paths(MODE)
conn = db.connect(P["db"])
SOURCE = db.get_meta(conn, "data_source", "unknown")
TAG = "  [SYNTHETIC DEMO DATA]" if SOURCE == "synthetic" else ""
def savefig(fig, name): fig.savefig(P["out"] / f"{name}.png", dpi=130, bbox_inches="tight")
print(f"mode = {MODE} | data source = {SOURCE} | database = {P['db'].name}")
if SOURCE == "synthetic":
    print("*** SYNTHETIC DEMO DATA: nothing below is a finding about real markets. "
          "Run `python run_pipeline.py` with internet, then re-run this notebook. ***")
'''

CELLS = [
    md('''
# IDC409 · Web Scraping I: Finance + News — **Exploratory Data Analysis**

Question: *does market movement have any relation with recent news keywords?*
This notebook covers: database read/write/modify · data quality · trends & moving averages ·
return distributions · keyword frequency · news↔return relationships · feature understanding & reduction.

**Data-source banner:** the first cell prints whether this run used `live` data (collected by
`run_pipeline.py`) or the bundled **synthetic demo** data. Figure titles carry a `[SYNTHETIC DEMO DATA]` tag
in the latter case.
'''),
    code(SETUP),

    md('## 1 · Database: read, write, modify (SQLite via `src/db.py`)'),
    code('''
print("tables:", db.read(conn, "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").name.tolist())
db.read(conn, """
    SELECT symbol, ticker, MIN(date) AS first_day, MAX(date) AS last_day, COUNT(*) AS n_days,
           ROUND(AVG(close), 2) AS avg_close, MAX(source) AS source
    FROM prices GROUP BY symbol ORDER BY symbol""")
'''),
    code('''
# READ: the news table (latest headlines)
db.read(conn, "SELECT pub_date, query, sentiment, title FROM news ORDER BY id DESC LIMIT 6")
'''),
    code('''
# WRITE + MODIFY demo on a throw-away copy, so the real data stays untouched.
conn.execute("DROP TABLE IF EXISTS scratch")
conn.execute("CREATE TABLE scratch AS SELECT date, symbol, close FROM prices WHERE symbol='NSEI' ORDER BY date DESC LIMIT 5")
show = lambda: db.read(conn, "SELECT * FROM scratch ORDER BY date")
print("original:\\n", show(), "\\n")

conn.execute("INSERT INTO scratch VALUES ('1999-01-01', 'TEST', 1.0)")                       # INSERT
conn.execute("UPDATE scratch SET close = ROUND(close * 1.5, 2) WHERE date = (SELECT MAX(date) FROM scratch)")  # UPDATE
conn.execute("DELETE FROM scratch WHERE date = (SELECT MIN(date) FROM scratch WHERE symbol='NSEI')")          # DELETE
conn.commit()
print("after INSERT + UPDATE + DELETE:\\n", show())
conn.execute("DROP TABLE scratch"); conn.commit()
# The same operations on the real tables are wrapped in db.upsert_prices / db.update_close / db.delete_where.
'''),

    md('## 2 · Data quality'),
    code('''
daily = pd.read_sql("SELECT * FROM daily", conn, parse_dates=["date"]).set_index("date")
df = pd.read_csv(P["csv"], parse_dates=["date"]).set_index("date")
print(f"`daily` table (raw engineered): {daily.shape} | cleaned CSV: {df.shape}")
miss = daily.isna().sum(); print("columns with missing values in raw table:\\n", miss[miss > 0].to_string())
print("duplicate dates:", int(df.index.duplicated().sum()))
gaps = df.index.to_series().diff().dt.days
print("largest calendar gaps between rows (days):", gaps.nlargest(3).astype(int).to_dict())
print("\\n" + (P["out"] / "cleaning_report.txt").read_text())
'''),

    md('## 3 · Trends and moving averages'),
    code('''
cat = {n: v[1] for n, v in config.SYMBOLS.items()}
assets = [n for n in config.SYMBOLS if (n == "NSEI" and "close" in daily) or f"{n}_close" in daily]
levels = pd.DataFrame({n: daily["close" if n == "NSEI" else f"{n}_close"] for n in assets}).dropna()
norm = levels / levels.iloc[0] * 100                      # indexed to 100 so different scales share one axis
fig, axes = plt.subplots(1, 2, figsize=(13, 4.2), sharex=True)
eq = [c for c in norm if cat[c] in ("index", "share")]; oth = [c for c in norm if c not in eq]
for ax, cols, title in [(axes[0], eq, "Indices and shares"), (axes[1], oth, "Gold, petrol, crude, currencies")]:
    for i, c in enumerate(cols):
        ax.plot(norm.index, norm[c], label=c, color=PAL[i % 8])
    ax.set_title(title); ax.axhline(100, color="#c3c2b7", lw=1); ax.legend(ncol=2, fontsize=8)
axes[0].set_ylabel("index (start = 100)")
fig.suptitle("Price trends, indexed to 100" + TAG, y=1.02, fontweight="bold"); fig.tight_layout()
savefig(fig, "eda_trends"); plt.show()
'''),
    code('''
c = daily["close"]; ma20, ma50 = c.rolling(20).mean(), c.rolling(50).mean()
cross = np.sign(ma20 - ma50).diff().fillna(0)
golden, death = cross[cross > 0].index, cross[cross < 0].index
fig, ax = plt.subplots(figsize=(12, 4.2))
ax.plot(c.index, c, color="#52514e", lw=1.1, label="Nifty close")
ax.plot(ma20.index, ma20, color=PAL[0], label="20-day MA"); ax.plot(ma50.index, ma50, color=PAL[1], label="50-day MA")
ax.scatter(golden, ma20.loc[golden], marker="^", s=45, color=PAL[2], zorder=3, label=f"20 crosses above 50 (n={len(golden)})")
ax.scatter(death, ma20.loc[death], marker="v", s=45, color=PAL[7], zorder=3, label=f"20 crosses below 50 (n={len(death)})")
ax.set_title("Nifty 50 with moving averages" + TAG); ax.legend(fontsize=8, ncol=2); fig.tight_layout()
savefig(fig, "eda_moving_averages"); plt.show()
# Does a MA crossover say anything about the NEXT day? (mean next-day return after each signal)
nxt = daily["target_ret"]
print(f"mean next-day return after 20>50 cross: {nxt.reindex(golden).mean():+.3f}% (n={nxt.reindex(golden).notna().sum()})")
print(f"mean next-day return after 20<50 cross: {nxt.reindex(death).mean():+.3f}% (n={nxt.reindex(death).notna().sum()})")
print(f"mean next-day return on all days      : {nxt.mean():+.3f}%")
'''),

    md('## 4 · Return distribution and volatility'),
    code('''
rcols = ["ret"] + [c for c in daily if c.endswith("_ret")]
R = daily[rcols].rename(columns={"ret": "NSEI_ret"}).dropna()
r = R["NSEI_ret"]
fig, axes = plt.subplots(1, 2, figsize=(11, 3.9))
axes[0].hist(r, bins=40, density=True, color=PAL[0], alpha=0.85, edgecolor="#fcfcfb")
xs = np.linspace(r.min(), r.max(), 300)
axes[0].plot(xs, stats.norm.pdf(xs, r.mean(), r.std()), color=PAL[1], label="normal, same mean/std")
axes[0].set_title("Nifty daily return (%)"); axes[0].legend(fontsize=8)
(osm, osr), (slope, intercept, _) = stats.probplot(r, dist="norm")
axes[1].scatter(osm, osr, s=10, color=PAL[0]); axes[1].plot(osm, slope * osm + intercept, color=PAL[1])
axes[1].set_title("Q-Q plot vs normal (fat tails bend away at the ends)"); axes[1].set_xlabel("theoretical quantiles")
fig.suptitle(TAG.strip(), y=1.0, fontsize=8); fig.tight_layout(); savefig(fig, "eda_return_distribution"); plt.show()

summary = pd.DataFrame({"mean %": R.mean(), "std %": R.std(), "skew": R.skew(), "excess kurtosis": R.kurt(),
                        "% up days": (R > 0).mean() * 100,
                        "Jarque-Bera p": [stats.jarque_bera(R[c]).pvalue for c in R]}).round(3)
summary
'''),
    code('''
vol20 = daily["ret"].rolling(20).std() * np.sqrt(252)
ac_ret = [r.autocorr(k) for k in range(1, 16)]; ac_abs = [r.abs().autocorr(k) for k in range(1, 16)]
fig, axes = plt.subplots(1, 2, figsize=(12, 3.8))
axes[0].plot(vol20.index, vol20, color=PAL[0]); axes[0].set_title("Nifty 20-day rolling volatility (annualised %)" + TAG)
w = 0.38; ks = np.arange(1, 16)
axes[1].bar(ks - w / 2, ac_ret, w, color=PAL[0], label="returns"); axes[1].bar(ks + w / 2, ac_abs, w, color=PAL[1], label="|returns|")
band = 1.96 / np.sqrt(len(r)); axes[1].axhline(band, color="#898781", lw=1, ls="--"); axes[1].axhline(-band, color="#898781", lw=1, ls="--")
axes[1].set_title("Autocorrelation (dashed = 95% noise band)"); axes[1].set_xlabel("lag (days)"); axes[1].legend(fontsize=8)
fig.tight_layout(); savefig(fig, "eda_volatility"); plt.show()
print(f"lag-1 autocorrelation of returns : {ac_ret[0]:+.3f}   (|r| < {band:.3f} is indistinguishable from noise)")
print(f"lag-1 autocorrelation of |returns|: {ac_abs[0]:+.3f}   -> volatility clustering means SIZE of moves is more predictable than DIRECTION")
'''),
    code('''
fig, ax = plt.subplots(figsize=(8.5, 6.5))
cm = R.corr()
sns.heatmap(cm, annot=True, fmt=".2f", cmap=DIVERGE, center=0, vmin=-1, vmax=1, linewidths=2, linecolor="#fcfcfb",
            annot_kws={"size": 7}, cbar_kws={"shrink": 0.7}, ax=ax)
ax.set_title("Correlation of same-day returns" + TAG); ax.grid(False); fig.tight_layout()
savefig(fig, "eda_return_correlation"); plt.show()
'''),

    md('## 5 · News keywords'),
    code('''
kw = [c for c in daily if c.startswith("kw_")]
tot = daily[kw].sum().rename(lambda s: s[3:]).sort_values()
share = tot / daily["n_headlines"].sum() * 100
print(f"headlines analysed: {int(daily['n_headlines'].sum()):,} over {int((daily['n_headlines'] > 0).sum())} trading days "
      f"(median {int(daily['n_headlines'].median())} per day)")
fig, ax = plt.subplots(figsize=(8, 6.2))
ax.barh(share.index, share.values, color=PAL[0], height=0.62)
ax.set_xlabel("% of headlines containing keyword"); ax.set_title("Keyword frequency" + TAG)
ax.grid(axis="y", visible=False); fig.tight_layout(); savefig(fig, "eda_keyword_frequency"); plt.show()
'''),
    code('''
top5 = tot.sort_values(ascending=False).index[:5]
fig, ax = plt.subplots(figsize=(12, 3.8))
for i, k in enumerate(top5):
    s = (daily[f"kwr_{k}"] * 100).rolling(20, min_periods=5).mean()
    ax.plot(s.index, s, color=PAL[i], label=k)
ax.set_ylabel("% of headlines (20-day mean)"); ax.set_title("Top-5 keywords over time" + TAG); ax.legend(ncol=5, fontsize=8)
fig.tight_layout(); savefig(fig, "eda_keyword_trends"); plt.show()
'''),
    code('''
sm = daily["sentiment_mean"].rolling(20, min_periods=5).mean()
fig, axes = plt.subplots(1, 2, figsize=(12, 3.8))
axes[0].plot(sm.index, sm, color=PAL[2]); axes[0].axhline(0, color="#c3c2b7", lw=1)
axes[0].set_title("Mean headline sentiment (20-day rolling)" + TAG)
d2 = daily[["sentiment_mean", "ret", "target_ret"]].dropna()
axes[1].scatter(d2["sentiment_mean"], d2["ret"], s=9, alpha=0.6, color=PAL[0], label="same-day return")
axes[1].scatter(d2["sentiment_mean"], d2["target_ret"], s=9, alpha=0.6, color=PAL[1], label="NEXT-day return")
axes[1].set_xlabel("daily mean sentiment"); axes[1].set_ylabel("Nifty return (%)"); axes[1].legend(fontsize=8)
axes[1].set_title("Sentiment vs return")
fig.tight_layout(); savefig(fig, "eda_sentiment"); plt.show()
for col in ("ret", "target_ret"):
    rho, p = stats.spearmanr(d2["sentiment_mean"], d2[col])
    print(f"Spearman(sentiment, {col:10s}) = {rho:+.3f}  (p = {p:.3g})")
'''),

    md('''
## 6 · Do news keywords relate to market movement?
Each keyword rate (share of that day's headlines) is correlated (Spearman, rank-based so outliers matter less) with
(a) the **same-day** return and (b) the **next-day** return. Only (b) is usable for prediction — (a) just says
whether news *describes* the day. With ~30 keywords, a few will pass p < 0.05 by luck, so a **Bonferroni** line is shown.
'''),
    code('''
cand = ["sentiment_mean", "neg_share", "n_headlines"] + [c for c in daily if c.startswith("kwr_")]
cand = [c for c in cand if daily[c].nunique() > 1]
base = daily[cand + ["ret", "target_ret", "next_abs_ret"]].dropna()
rows = []
for c in cand:
    r0, p0 = stats.spearmanr(base[c], base["ret"])
    r1, p1 = stats.spearmanr(base[c], base["target_ret"])
    r2, p2 = stats.spearmanr(base[c], base["next_abs_ret"])
    rows.append((c.replace("kwr_", ""), r0, p0, r1, p1, r2, p2))
cor = pd.DataFrame(rows, columns=["feature", "rho_same_day", "p_same", "rho_next_day", "p_next", "rho_next_|move|", "p_abs"]).set_index("feature")
cor = cor.dropna()                                  # a keyword that never occurs has no correlation
alpha, m = 0.05, len(cor); bonf = alpha / m
fig, ax = plt.subplots(figsize=(9, 7.5)); order = cor["rho_same_day"].abs().sort_values().index
y = np.arange(len(order)); h = 0.38
ax.barh(y + h / 2, cor.loc[order, "rho_same_day"], h, color=PAL[0], label="same-day return")
ax.barh(y - h / 2, cor.loc[order, "rho_next_day"], h, color=PAL[1], label="NEXT-day return")
ax.set_yticks(y); ax.set_yticklabels(order); ax.axvline(0, color="#898781", lw=1)
crit = 1.96 / np.sqrt(len(base)); ax.axvspan(-crit, crit, color="#e1e0d9", alpha=0.5, zorder=0, label="|rho| below 95% noise band")
ax.set_xlabel("Spearman rho"); ax.legend(fontsize=8, loc="lower right"); ax.grid(axis="y", visible=False)
ax.set_title("News features vs Nifty return: same day vs next day" + TAG); fig.tight_layout()
savefig(fig, "eda_news_correlation"); plt.show()

print(f"{m} news features tested on {len(base)} days. Chance alone gives ~{alpha * m:.1f} 'significant' at p<0.05 per target.")
for col, name in [("p_same", "same-day"), ("p_next", "next-day"), ("p_abs", "next-day |move|")]:
    print(f"  {name:16s}: {(cor[col] < alpha).sum():2d} with p<0.05, {(cor[col] < bonf).sum():2d} survive Bonferroni (p<{bonf:.4f})")
cor.reindex(cor["rho_next_day"].abs().sort_values(ascending=False).index).head(8).round(3)
'''),

    md('## 7 · Understanding and reducing the features'),
    code('''
G = features.feature_groups(df.columns)
print({k: len(v) for k, v in G.items()}, "-> total", sum(len(v) for v in G.values()), "model features")
print("\\nTECHNICAL (from the Nifty price series itself):", G["tech"])
print("CROSS-ASSET (gold, petrol, crude, FX, peers):", G["cross"])
print("NEWS (counts converted to per-headline rates):", [c for c in G["news"] if not c.startswith("kwr_")], "+ kwr_* keyword rates")
df[G["tech"] + G["cross"]].describe().T[["mean", "std", "min", "max"]].round(3)
'''),
    code('''
ALL = G["tech"] + G["cross"] + G["news"]
C = df[ALL].corr().abs()
pairs = [(a, b, C.loc[a, b]) for i, a in enumerate(ALL) for b in ALL[i + 1:] if C.loc[a, b] > 0.8]
print("feature pairs with |correlation| > 0.8 (redundant information):")
for a, b, v in sorted(pairs, key=lambda t: -t[2]): print(f"  {a:14s} ~ {b:14s}  {v:.2f}")
drop = []                                      # greedy: keep the first of each correlated pair
for a in ALL:
    if a in drop: continue
    drop += [b for b in ALL if b != a and b not in drop and ALL.index(b) > ALL.index(a) and C.loc[a, b] > 0.9]
print("\\nwould drop at |r| > 0.9:", drop if drop else "nothing")
'''),
    code('''
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
Z = StandardScaler().fit_transform(df[ALL]); pca = PCA().fit(Z)
cum = pca.explained_variance_ratio_.cumsum(); k90 = int(np.searchsorted(cum, 0.90) + 1)
fig, ax = plt.subplots(figsize=(7.5, 3.8))
ax.plot(range(1, len(cum) + 1), cum * 100, color=PAL[0], marker="o", ms=3)
ax.axhline(90, color="#898781", ls="--", lw=1); ax.axvline(k90, color=PAL[1], lw=1.2)
ax.set_xlabel("number of principal components"); ax.set_ylabel("cumulative variance explained (%)")
ax.set_title(f"PCA: {k90} of {len(ALL)} components keep 90% of variance" + TAG); fig.tight_layout()
savefig(fig, "eda_pca"); plt.show()
print(f"{len(ALL)} features -> {k90} components for 90% variance ({k90 / len(ALL):.0%} of the original count). "
      "The closer this ratio is to 100%, the less redundant the features are, and the less PCA can compress.")
'''),

    md('## 8 · Summary of observations (computed from the data above)'),
    code('''
best_next = cor["rho_next_day"].abs().idxmax(); best_same = cor["rho_same_day"].abs().idxmax()
print(f"Data: {len(df)} trading days, {df.index.min().date()} -> {df.index.max().date()}  [{SOURCE}]")
print(f"1. Returns are fat-tailed (excess kurtosis {r.kurt():.2f}); lag-1 return autocorrelation is {ac_ret[0]:+.3f}.")
print(f"2. Volatility clusters: lag-1 autocorrelation of |return| is {ac_abs[0]:+.3f}.")
print(f"3. Strongest SAME-day news link: {best_same} (rho {cor.loc[best_same, 'rho_same_day']:+.2f}); "
      f"strongest NEXT-day link: {best_next} (rho {cor.loc[best_next, 'rho_next_day']:+.2f}, p={cor.loc[best_next, 'p_next']:.3g}).")
n_next = int((cor['p_next'] < bonf).sum())
print(f"4. {n_next} of {m} features survive Bonferroni for next-day return."
      + ("  -> no reliable next-day news signal in this sample." if n_next == 0 else "  -> check these carefully in the model notebook."))
print("Interpretation guide: a strong same-day but weak next-day link means news mostly REPORTS the move rather than predicts it.")
'''),
]
