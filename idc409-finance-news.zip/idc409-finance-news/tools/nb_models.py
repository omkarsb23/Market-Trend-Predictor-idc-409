from nbtools import code, md
from nb_eda import SETUP as _EDA_SETUP

SETUP = _EDA_SETUP.replace("from src import db, features", "from src import db, features\nimport time") + '''
from sklearn.base import clone
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression, Ridge, LogisticRegression
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.svm import SVR, SVC
from sklearn.model_selection import TimeSeriesSplit, GridSearchCV
from sklearn.inspection import permutation_importance
from sklearn.metrics import (mean_absolute_error, mean_squared_error, r2_score, accuracy_score, f1_score,
                             precision_score, recall_score, confusion_matrix)
SEED = 409
'''

CELLS = [
    md('''
# IDC409 · Web Scraping I: Finance + News — **Prediction models**

Modest goals, honestly evaluated: predict the **next trading day's** Nifty move.

| Task | Target | Models | Metrics |
|---|---|---|---|
| Regression | next-day return (%) and implied next-day price | Linear, Ridge, Decision Tree, Random Forest, SVR | MAE, RMSE, R² |
| Classification A | Up / Down | Logistic, Decision Tree, Random Forest, SVM | F1, accuracy, confusion matrix |
| Classification B | High / Low move (|next return| above the training median) | same | same |

**Rules that keep it honest**
* **Time-based split** (first 80 % train, last 20 % test) with a 1-day gap — never a random split.
* Hyper-parameters tuned only on the training period with `TimeSeriesSplit`; scaling is fitted inside each pipeline.
* Every model is compared with a **naive baseline** (tomorrow = today, majority class, persistence).
* A single ~100-day test window is noisy, so results are re-checked with **walk-forward validation** (5 folds).
* An **ablation** adds feature groups one at a time to see whether news keywords add anything beyond prices.
'''),
    code(SETUP),
    code('''
df = pd.read_csv(P["csv"], parse_dates=["date"]).set_index("date")
G = features.feature_groups(df.columns)
FS = {"tech": G["tech"], "tech+cross": G["tech"] + G["cross"], "tech+cross+news": G["tech"] + G["cross"] + G["news"], "news only": G["news"]}
ALL = FS["tech+cross+news"]
print(f"{len(df)} rows | features: " + ", ".join(f"{k}={len(v)}" for k, v in G.items()) + f" | data source: {SOURCE}")

n = len(df); split = int(n * 0.8); GAP = 1
train, test = df.iloc[: split - GAP], df.iloc[split:]
print(f"train: {train.index.min().date()} -> {train.index.max().date()} ({len(train)} days)")
print(f"test : {test.index.min().date()} -> {test.index.max().date()} ({len(test)} days)   [1-day gap between them]")

thr = train["next_abs_ret"].median()                      # High/Low threshold from TRAIN only
Y = {"reg": df["target_ret"], "dir": df["target_dir"].astype(int), "hl": (df["next_abs_ret"] > thr).astype(int)}
print(f"High/Low threshold (train median |next return|): {thr:.3f}%")
print(f"share of Up days  train {Y['dir'].loc[train.index].mean():.1%} | test {Y['dir'].loc[test.index].mean():.1%}")
print(f"share of High days train {Y['hl'].loc[train.index].mean():.1%} | test {Y['hl'].loc[test.index].mean():.1%}")
'''),

    md('## 1 · Regression: next-day return and price'),
    code('''
def reg_metrics(df_part, pred_pct):
    y = df_part["target_ret"].values
    pp = df_part["close"].values * (1 + np.asarray(pred_pct) / 100)          # implied next-day price
    return {"MAE_ret": mean_absolute_error(y, pred_pct), "RMSE_ret": mean_squared_error(y, pred_pct) ** 0.5,
            "R2_ret": r2_score(y, pred_pct),
            "MAE_price": mean_absolute_error(df_part["next_close"], pp),
            "RMSE_price": mean_squared_error(df_part["next_close"], pp) ** 0.5,
            "R2_price": r2_score(df_part["next_close"], pp)}

def tuned(est, grid, X, y, scoring):
    pipe = Pipeline([("sc", StandardScaler()), ("m", est)])
    if not grid:
        return pipe.fit(X, y), {}
    gs = GridSearchCV(pipe, grid, cv=TimeSeriesSplit(5), scoring=scoring, n_jobs=1).fit(X, y)
    return gs.best_estimator_, {k.replace("m__", ""): v for k, v in gs.best_params_.items()}

REG = {
    "Linear Regression": (LinearRegression(), {}),
    "Ridge":             (Ridge(), {"m__alpha": [1, 10, 100, 1000, 10000]}),
    "Decision Tree":     (DecisionTreeRegressor(random_state=SEED), {"m__max_depth": [2, 3, 5], "m__min_samples_leaf": [10, 25, 50]}),
    "Random Forest":     (RandomForestRegressor(n_estimators=200, random_state=SEED, n_jobs=1), {"m__max_depth": [3, 5], "m__min_samples_leaf": [10, 30]}),
    "SVR (RBF)":         (SVR(kernel="rbf"), {"m__C": [0.1, 1, 10], "m__epsilon": [0.05, 0.3], "m__gamma": ["scale", 0.01]}),
}
Xtr, Xte = train[ALL], test[ALL]
ytr = Y["reg"].loc[train.index]
rows, preds, params, fitted_reg = {}, {}, {}, {}
rows["Naive: tomorrow = today (0% return)"] = reg_metrics(test, np.zeros(len(test)))
rows["Naive: train-mean return"] = reg_metrics(test, np.full(len(test), ytr.mean()))
for name, (est, grid) in REG.items():
    m, bp = tuned(est, grid, Xtr, ytr, "neg_mean_absolute_error")
    fitted_reg[name], params[name] = m, bp
    preds[name] = m.predict(Xte); rows[name] = reg_metrics(test, preds[name])
reg_tbl = pd.DataFrame(rows).T
reg_tbl["MAE vs naive"] = reg_tbl["MAE_ret"] / reg_tbl.loc["Naive: tomorrow = today (0% return)", "MAE_ret"]
reg_tbl.round(4).to_csv(P["out"] / "regression_metrics.csv")
print("best hyper-parameters:", params)
reg_tbl.round(4)
'''),
    md('''
**Reading the table.** `*_ret` columns score the return forecast (what matters). `*_price` columns score the implied
price; because tomorrow's price is almost today's price, **R²_price is ≈ 1 for everything, including the naive
baseline**, so it says nothing about skill — compare `MAE_price` with the naive row instead.
`MAE vs naive` < 1 means the model has lower return error than "no change".
'''),
    code('''
best_reg = reg_tbl.drop(index=[i for i in reg_tbl.index if i.startswith("Naive")])["MAE_ret"].idxmin()
fig, axes = plt.subplots(1, 2, figsize=(13, 4.2))
names = list(reg_tbl.index); vals = reg_tbl["MAE_price"].values
cols = ["#898781" if nm.startswith("Naive") else PAL[0] for nm in names]
axes[0].barh(names[::-1], vals[::-1], color=cols[::-1], height=0.6); axes[0].set_xlabel("MAE of implied next-day price (index points)")
axes[0].set_title("Test-set price error (grey = naive baselines)" + TAG); axes[0].grid(axis="y", visible=False)
axes[1].plot(test.index, test["target_ret"], color="#898781", lw=1, label="actual")
axes[1].plot(test.index, preds[best_reg], color=PAL[1], lw=1.6, label=f"{best_reg} forecast")
axes[1].axhline(0, color="#c3c2b7", lw=1); axes[1].set_title("Next-day return (%): actual vs best model"); axes[1].legend(fontsize=8)
import matplotlib.dates as mdates
loc = mdates.AutoDateLocator(); axes[1].xaxis.set_major_locator(loc); axes[1].xaxis.set_major_formatter(mdates.ConciseDateFormatter(loc))
fig.tight_layout(); savefig(fig, "model_regression"); plt.show()
print("best regression model by return MAE:", best_reg, "| forecast std %.3f vs actual std %.3f" % (preds[best_reg].std(), test["target_ret"].std()))
'''),

    md('## 2 · Classification: Up/Down and High/Low'),
    code('''
CLF = {
    "Logistic Regression": (LogisticRegression(max_iter=2000), {"m__C": [0.001, 0.01, 0.1, 1, 10]}),
    "Decision Tree":       (DecisionTreeClassifier(random_state=SEED), {"m__max_depth": [2, 3, 5], "m__min_samples_leaf": [10, 25, 50]}),
    "Random Forest":       (RandomForestClassifier(n_estimators=200, random_state=SEED, n_jobs=1), {"m__max_depth": [3, 5], "m__min_samples_leaf": [10, 30]}),
    "SVM (RBF)":           (SVC(kernel="rbf"), {"m__C": [0.1, 1, 10], "m__gamma": ["scale", 0.01]}),
}
def clf_metrics(y, p):
    return {"accuracy": accuracy_score(y, p), "precision_1": precision_score(y, p, zero_division=0),
            "recall_1": recall_score(y, p, zero_division=0), "F1_1": f1_score(y, p, zero_division=0),
            "F1_macro": f1_score(y, p, average="macro", zero_division=0)}

def run_clf(key, positive_name, persistence):
    ytr_, yte_ = Y[key].loc[train.index], Y[key].loc[test.index]
    maj = int(ytr_.mean() >= 0.5)
    rows, cms, preds_, fit_, bps = {}, {}, {}, {}, {}
    base = {f"Baseline: always {maj}(majority)": np.full(len(yte_), maj), "Baseline: persistence (tomorrow = today)": persistence}
    for nm, p in base.items():
        rows[nm] = clf_metrics(yte_, p); cms[nm] = confusion_matrix(yte_, p, labels=[0, 1])
    for nm, (est, grid) in CLF.items():
        m, bp = tuned(est, grid, Xtr, ytr_, "f1_macro")
        p = m.predict(Xte); fit_[nm], preds_[nm], bps[nm] = m, p, bp
        rows[nm] = clf_metrics(yte_, p); cms[nm] = confusion_matrix(yte_, p, labels=[0, 1])
    tbl = pd.DataFrame(rows).T
    maj_acc = rows[list(base)[0]]["accuracy"]
    tbl["p(acc > majority)"] = [1.0 if nm in base else stats.binomtest(int(round(rows[nm]["accuracy"] * len(yte_))), len(yte_), maj_acc, alternative="greater").pvalue for nm in tbl.index]
    return tbl, cms, preds_, fit_, bps

persist_dir = (test["ret"] > 0).astype(int).values
tbl_dir, cm_dir, pr_dir, fit_dir, bp_dir = run_clf("dir", "Up", persist_dir)
tbl_dir.round(4).to_csv(P["out"] / "classification_direction_metrics.csv")
print("Up/Down  (1 = next day up)   best params:", bp_dir)
tbl_dir.round(4)
'''),
    code('''
persist_hl = (test["ret"].abs() > thr).astype(int).values
tbl_hl, cm_hl, pr_hl, fit_hl, bp_hl = run_clf("hl", "High", persist_hl)
tbl_hl.round(4).to_csv(P["out"] / "classification_highlow_metrics.csv")
print("High/Low  (1 = |next-day move| above training median)   best params:", bp_hl)
tbl_hl.round(4)
'''),
    code('''
def plot_cms(cms, title, fname):
    items = list(cms.items()); ncol = 3; nrow = int(np.ceil(len(items) / ncol))
    fig, axes = plt.subplots(nrow, ncol, figsize=(10.5, 3.3 * nrow)); axes = np.atleast_1d(axes).ravel()
    for ax, (nm, cm) in zip(axes, items):
        ax.imshow(cm, cmap=sns.light_palette(PAL[0], as_cmap=True), vmin=0, vmax=max(cm.max(), 1))
        for (i, j), v in np.ndenumerate(cm):
            ax.text(j, i, int(v), ha="center", va="center", fontsize=13, color="white" if v > cm.max() * 0.6 else INK)
        ax.set_xticks([0, 1]); ax.set_yticks([0, 1]); ax.set_xticklabels(["pred 0", "pred 1"]); ax.set_yticklabels(["actual 0", "actual 1"])
        ax.set_title(nm.replace("Baseline: ", "Base: "), fontsize=9); ax.grid(False)
    for ax in axes[len(items):]: ax.axis("off")
    fig.suptitle(title + TAG, y=1.0, fontweight="bold"); fig.tight_layout(); savefig(fig, fname); plt.show()
plot_cms(cm_dir, "Confusion matrices — Up(1)/Down(0), test period", "model_confusion_direction")
plot_cms(cm_hl, "Confusion matrices — High(1)/Low(0) move, test period", "model_confusion_highlow")
'''),

    md('''
## 3 · Robustness: walk-forward validation
One 100-day test window can flatter or punish a model by luck. Here every model is re-fitted (same tuned
hyper-parameters) on an expanding window and tested on 5 consecutive later blocks.
`MAE ratio` < 1 ⇒ beats "no change"; for classification the baseline is the majority class of each training block.
'''),
    code('''
tscv = TimeSeriesSplit(5)
Xall = df[ALL]

def wf_reg(model, X, y):
    ratios, r2s = [], []
    for tr, te in tscv.split(X):
        m = clone(model).fit(X.iloc[tr], y.iloc[tr]); p = m.predict(X.iloc[te])
        ratios.append(mean_absolute_error(y.iloc[te], p) / mean_absolute_error(y.iloc[te], np.zeros(len(te)))); r2s.append(r2_score(y.iloc[te], p))
    return np.mean(ratios), np.std(ratios), np.mean(r2s)

def wf_clf(model, X, y):
    f1s, accs, bf1, bacc = [], [], [], []
    for tr, te in tscv.split(X):
        m = clone(model).fit(X.iloc[tr], y.iloc[tr]); p = m.predict(X.iloc[te]); yt = y.iloc[te]
        maj = int(y.iloc[tr].mean() >= 0.5)
        f1s.append(f1_score(yt, p, average="macro")); accs.append(accuracy_score(yt, p))
        bf1.append(f1_score(yt, np.full(len(yt), maj), average="macro", zero_division=0)); bacc.append(accuracy_score(yt, np.full(len(yt), maj)))
    return np.mean(f1s), np.std(f1s), np.mean(accs), np.mean(bf1), np.mean(bacc)

wf = []
for nm, m in fitted_reg.items():
    a, s, r2m = wf_reg(m, Xall, Y["reg"]); wf.append(("return regression", nm, a, s, r2m, np.nan, np.nan))
for task, fits, key in [("Up/Down", fit_dir, "dir"), ("High/Low", fit_hl, "hl")]:
    for nm, m in fits.items():
        f1m, f1s, acc, bf1, bacc = wf_clf(m, Xall, Y[key]); wf.append((task, nm, f1m, f1s, acc, bf1, bacc))
wf_tbl = pd.DataFrame(wf, columns=["task", "model", "primary (MAE ratio | F1 macro)", "std over folds", "R2 | accuracy", "baseline F1 macro", "baseline accuracy"])
wf_tbl.round(3).to_csv(P["out"] / "walk_forward_metrics.csv", index=False)
wf_tbl.round(3)
'''),

    md('''
## 4 · Ablation: do news keywords add anything?
Same fixed, lightly-regularised models, feature groups added one at a time, scored by walk-forward validation
(more stable than the single hold-out). The row that matters is **tech+cross → tech+cross+news**.
'''),
    code('''
ABL = {"reg": ("Ridge(alpha=100)", Pipeline([("sc", StandardScaler()), ("m", Ridge(alpha=100))])),
       "dir-LR": ("Logistic(C=0.05)", Pipeline([("sc", StandardScaler()), ("m", LogisticRegression(C=0.05, max_iter=2000))])),
       "dir-RF": ("RandomForest(d4,leaf20)", Pipeline([("sc", StandardScaler()), ("m", RandomForestClassifier(n_estimators=200, max_depth=4, min_samples_leaf=20, random_state=SEED, n_jobs=1))])),
       "hl-RF": ("RandomForest(d4,leaf20)", Pipeline([("sc", StandardScaler()), ("m", RandomForestClassifier(n_estimators=200, max_depth=4, min_samples_leaf=20, random_state=SEED, n_jobs=1))]))}
rows = []
for fs, cols_ in FS.items():
    X = df[cols_]
    ratio, _, _ = wf_reg(ABL["reg"][1], X, Y["reg"])
    f1_lr = wf_clf(ABL["dir-LR"][1], X, Y["dir"])[0]; f1_rf = wf_clf(ABL["dir-RF"][1], X, Y["dir"])[0]
    f1_hl = wf_clf(ABL["hl-RF"][1], X, Y["hl"])[0]
    rows.append((fs, len(cols_), ratio, f1_lr, f1_rf, f1_hl))
abl = pd.DataFrame(rows, columns=["feature set", "# feats", "Return: MAE ratio vs naive (lower=better)",
                                  "Up/Down F1 (Logistic)", "Up/Down F1 (RF)", "High/Low F1 (RF)"]).set_index("feature set")
abl.round(3).to_csv(P["out"] / "ablation.csv")
abl.round(3)
'''),
    code('''
d = abl.loc["tech+cross+news"] - abl.loc["tech+cross"]
print("Effect of ADDING news features to tech+cross (walk-forward):")
print(f"  Return MAE ratio : {d.iloc[1]:+.4f}  ({'worse' if d.iloc[1] > 0 else 'better'}; lower is better)")
print(f"  Up/Down F1  (LR) : {d.iloc[2]:+.4f}")
print(f"  Up/Down F1  (RF) : {d.iloc[3]:+.4f}")
print(f"  High/Low F1 (RF) : {d.iloc[4]:+.4f}")
fig, ax = plt.subplots(figsize=(9, 3.8)); idx = np.arange(len(abl)); w = 0.26
for i, (c, lab) in enumerate([("Up/Down F1 (RF)", "Up/Down F1 (RF)"), ("High/Low F1 (RF)", "High/Low F1 (RF)"), ("Up/Down F1 (Logistic)", "Up/Down F1 (Logistic)")]):
    ax.bar(idx + (i - 1) * w, abl[c], w * 0.92, color=PAL[i], label=lab)
ax.axhline(0.5, color="#898781", ls="--", lw=1); ax.set_xticks(idx); ax.set_xticklabels(abl.index)
ax.set_ylabel("walk-forward macro-F1 (dashed = coin flip)"); ax.set_ylim(0.3, max(0.7, abl.iloc[:, 2:].max().max() + 0.05))
ax.set_title("Adding feature groups" + TAG); ax.legend(fontsize=8, ncol=3); fig.tight_layout(); savefig(fig, "model_ablation"); plt.show()
'''),

    md('''
## 5 · Feature selection and reduction
Three reductions, all decided **using the training period only**:
(1) drop near-duplicates (|r| > 0.9), (2) keep the top-k features by random-forest importance, (3) PCA to 90 % variance.
Permutation importance (on a validation slice at the end of the training period) shows which features carry signal.
'''),
    code('''
Cm = train[ALL].corr().abs(); dropped = []
for i, a in enumerate(ALL):
    if a in dropped: continue
    dropped += [b for b in ALL[i + 1:] if b not in dropped and Cm.loc[a, b] > 0.9]
KEEP_CORR = [c for c in ALL if c not in dropped]
print(f"correlation filter drops {len(dropped)}: {dropped}")

cut = int(len(train) * 0.75); trn, val = train.iloc[:cut], train.iloc[cut:]
rf_c = RandomForestClassifier(n_estimators=300, max_depth=4, min_samples_leaf=20, random_state=SEED, n_jobs=1).fit(trn[ALL], Y["dir"].loc[trn.index])
rf_r = RandomForestRegressor(n_estimators=300, max_depth=4, min_samples_leaf=20, random_state=SEED, n_jobs=1).fit(trn[ALL], Y["reg"].loc[trn.index])
pi_c = permutation_importance(rf_c, val[ALL], Y["dir"].loc[val.index], n_repeats=15, random_state=SEED, scoring="accuracy")
pi_r = permutation_importance(rf_r, val[ALL], Y["reg"].loc[val.index], n_repeats=15, random_state=SEED, scoring="neg_mean_absolute_error")
imp = pd.DataFrame({"perm_importance_direction": pi_c.importances_mean, "perm_importance_return": pi_r.importances_mean,
                    "rf_impurity_direction": rf_c.feature_importances_}, index=ALL)
imp.round(5).to_csv(P["out"] / "feature_importance.csv")
fig, axes = plt.subplots(1, 2, figsize=(12.5, 5))
for ax, col, ttl, c in [(axes[0], "perm_importance_direction", "Up/Down: accuracy lost when feature is shuffled", PAL[0]),
                        (axes[1], "perm_importance_return", "Return: MAE increase when feature is shuffled", PAL[1])]:
    top = imp[col].sort_values().tail(12)
    ax.barh(top.index, top.values, color=c, height=0.62); ax.axvline(0, color="#898781", lw=1); ax.set_title(ttl, fontsize=10); ax.grid(axis="y", visible=False)
fig.suptitle("Permutation importance on validation slice (top 12; ~0 or negative = no signal)" + TAG, y=1.0, fontweight="bold")
fig.tight_layout(); savefig(fig, "model_feature_importance"); plt.show()
grp = {c: g for g, cs in G.items() for c in cs}
imp["group"] = imp.index.map(grp)
print("sum of positive permutation importance (direction) by group:")
imp.groupby("group")["perm_importance_direction"].apply(lambda s: s.clip(lower=0).sum()).round(4).to_dict()
'''),
    code('''
K = 10
topk = imp["rf_impurity_direction"].sort_values(ascending=False).head(K).index.tolist()
print("top-10 by RF importance (train only):", topk)
mk_lr = lambda: Pipeline([("sc", StandardScaler()), ("m", LogisticRegression(C=0.05, max_iter=2000))])
mk_rf = lambda: Pipeline([("sc", StandardScaler()), ("m", RandomForestClassifier(n_estimators=200, max_depth=4, min_samples_leaf=20, random_state=SEED, n_jobs=1))])
mk_pca = lambda: Pipeline([("sc", StandardScaler()), ("pca", PCA(0.90)), ("m", LogisticRegression(C=0.05, max_iter=2000))])
ytr_d, yte_d = Y["dir"].loc[train.index], Y["dir"].loc[test.index]
rows = []
for label, cols_, mk in [(f"all {len(ALL)} features", ALL, mk_lr), (f"correlation filter ({len(KEEP_CORR)})", KEEP_CORR, mk_lr),
                         (f"top-{K} by RF importance", topk, mk_lr), ("PCA (90% variance) + Logistic", ALL, mk_pca),
                         (f"all {len(ALL)} features", ALL, mk_rf), (f"top-{K} by RF importance", topk, mk_rf)]:
    m = mk().fit(train[cols_], ytr_d); p = m.predict(test[cols_])
    nm = "RF" if mk is mk_rf else "Logistic"
    rows.append((nm, label, len(cols_) if "PCA" not in label else m.named_steps["pca"].n_components_, accuracy_score(yte_d, p), f1_score(yte_d, p, average="macro")))
red = pd.DataFrame(rows, columns=["model", "feature set", "# inputs", "accuracy", "F1 macro"]).set_index(["model", "feature set"])
red.round(3).to_csv(P["out"] / "feature_reduction.csv")
red.round(3)
'''),

    md('## 6 · Verdict (computed from the results above)'),
    code('''
naive_row = "Naive: tomorrow = today (0% return)"
bm = reg_tbl.loc[best_reg]
print(f"DATA: {SOURCE}  |  test window {test.index.min().date()} -> {test.index.max().date()} ({len(test)} days)")
print()
print("REGRESSION (next-day return)")
print(f"  best model: {best_reg} | MAE {bm['MAE_ret']:.3f}% vs naive {reg_tbl.loc[naive_row, 'MAE_ret']:.3f}% (ratio {bm['MAE vs naive']:.3f}) | R2 {bm['R2_ret']:+.3f}")
print(f"  implied price MAE {bm['MAE_price']:.1f} vs naive {reg_tbl.loc[naive_row, 'MAE_price']:.1f} index points")
wfr = wf_tbl[wf_tbl.task == "return regression"].set_index("model")["primary (MAE ratio | F1 macro)"]
print(f"  walk-forward MAE ratios (1.0 = same as naive): " + ", ".join(f"{k} {v:.3f}" for k, v in wfr.items()))
print("  ->", "some evidence of skill; verify with walk-forward" if (bm['MAE vs naive'] < 1 and bm['R2_ret'] > 0 and (wfr < 1).all()) else "NO reliable improvement over the naive 'tomorrow = today' baseline.")
print()
n_models = len(CLF)
for title, tbl, key in [("UP/DOWN", tbl_dir, "Up/Down"), ("HIGH/LOW MOVE", tbl_hl, "High/Low")]:
    mdl = tbl.drop(index=[i for i in tbl.index if i.startswith("Baseline")])
    b = mdl["F1_macro"].idxmax(); bl = tbl[[i.startswith("Baseline") for i in tbl.index]]["F1_macro"]
    w = wf_tbl[wf_tbl.task == key].set_index("model").loc[b]
    p_b = mdl.loc[b, "p(acc > majority)"]
    print(f"{title}: best on hold-out = {b}: F1 macro {mdl.loc[b, 'F1_macro']:.3f}, accuracy {mdl.loc[b, 'accuracy']:.3f} | best baseline F1 macro {bl.max():.3f}")
    print(f"  binomial p vs majority-class accuracy: {p_b:.3f} (Bonferroni threshold for {n_models} models tried: {0.05 / n_models:.4f})")
    print(f"  walk-forward: accuracy {w['R2 | accuracy']:.3f} vs majority baseline {w['baseline accuracy']:.3f}")
    ok = mdl.loc[b, "F1_macro"] > bl.max() and p_b < 0.05 / n_models and w["R2 | accuracy"] > w["baseline accuracy"]
    print("  ->", "evidence of skill: beats baselines on hold-out AND walk-forward, significant after multiple-testing correction" if ok
          else "no reliable skill: not significant after correcting for the number of models tried, or not confirmed by walk-forward.")
print()
dd = abl.loc["tech+cross+news"] - abl.loc["tech+cross"]
print(f"NEWS: adding keyword/sentiment features changes walk-forward F1 by {dd.iloc[2]:+.3f} (LR), {dd.iloc[3]:+.3f} (RF) for Up/Down and {dd.iloc[4]:+.3f} for High/Low.")
print("CAVEATS: ~100-day test window -> wide uncertainty; many models were tried (some will look good by chance);")
print("         headline sentiment is a simple lexicon; Google News queries are a biased sample; this is not trading advice.")
if SOURCE == "synthetic":
    print("\\n*** These numbers come from SYNTHETIC data with no planted next-day signal; they only demonstrate that the pipeline works. ***")
'''),
]
