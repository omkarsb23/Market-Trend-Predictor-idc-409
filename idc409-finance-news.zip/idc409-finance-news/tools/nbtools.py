"""Tiny notebook writer + executor (so notebooks ship WITH outputs even without Jupyter installed).

Cells are executed top-to-bottom in one shared namespace, like a Jupyter kernel: stdout, the value of
a trailing expression and every open matplotlib figure are captured into the .ipynb outputs.
Users do not need this file - they just open the notebooks in Jupyter and "Run All".
"""
from __future__ import annotations

import ast
import base64
import contextlib
import io
import json
import os
import traceback
import uuid
from pathlib import Path


def md(src: str):
    return ("md", src.strip("\n"))


def code(src: str):
    return ("code", src.strip("\n"))


def _lines(s: str) -> list[str]:
    return s.splitlines(keepends=True)


def run_and_save(cells, out_path: Path, cwd: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    old = os.getcwd()
    os.chdir(cwd)
    ns: dict = {"__name__": "__main__"}
    nb_cells, count = [], 0
    try:
        for idx, (kind, src) in enumerate(cells):
            cid = uuid.uuid4().hex[:8]
            if kind == "md":
                nb_cells.append({"cell_type": "markdown", "id": cid, "metadata": {}, "source": _lines(src)})
                continue
            count += 1
            outputs = []
            out, err = io.StringIO(), io.StringIO()
            tree = ast.parse(src)
            last = tree.body.pop() if tree.body and isinstance(tree.body[-1], ast.Expr) else None
            value = None
            try:
                with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                    exec(compile(tree, f"<cell {idx}>", "exec"), ns)
                    if last is not None:
                        value = eval(compile(ast.Expression(last.value), f"<cell {idx}>", "eval"), ns)
            except Exception:
                print(f"\n!!! error in cell {idx}:\n{src}\n")
                traceback.print_exc()
                raise
            if out.getvalue():
                outputs.append({"output_type": "stream", "name": "stdout", "text": _lines(out.getvalue())})
            if err.getvalue():
                outputs.append({"output_type": "stream", "name": "stderr", "text": _lines(err.getvalue())})
            for num in plt.get_fignums():
                buf = io.BytesIO()
                plt.figure(num).savefig(buf, format="png", dpi=110, bbox_inches="tight")
                outputs.append({"output_type": "display_data", "metadata": {}, "data": {
                    "image/png": base64.b64encode(buf.getvalue()).decode(),
                    "text/plain": ["<Figure>"]}})
            plt.close("all")
            if value is not None:
                data = {"text/plain": _lines(repr(value))}
                if hasattr(value, "_repr_html_"):
                    html = value._repr_html_()
                    if html:
                        data["text/html"] = _lines(html)
                outputs.append({"output_type": "execute_result", "execution_count": count,
                                "metadata": {}, "data": data})
            nb_cells.append({"cell_type": "code", "id": cid, "metadata": {}, "execution_count": count,
                             "outputs": outputs, "source": _lines(src)})
    finally:
        os.chdir(old)
    nb = {"cells": nb_cells, "nbformat": 4, "nbformat_minor": 5, "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python"}}}
    out_path.write_text(json.dumps(nb, indent=1))
