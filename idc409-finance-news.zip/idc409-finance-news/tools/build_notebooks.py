#!/usr/bin/env python3
"""(Re)generate notebooks/*.ipynb WITH executed outputs.  Usage: python tools/build_notebooks.py [live|demo]

Developer helper only - end users simply open the notebooks in Jupyter and Run All.
"""
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(ROOT))

if len(sys.argv) > 1:
    os.environ["IDC409_MODE"] = sys.argv[1]

from nbtools import run_and_save  # noqa: E402
import nb_eda, nb_models  # noqa: E402

for name, mod in [("01_eda.ipynb", nb_eda), ("02_models.ipynb", nb_models)]:
    print("building", name, flush=True)
    run_and_save(mod.CELLS, ROOT / "notebooks" / name, ROOT / "notebooks")
print("done")
