"""Headline sentiment.

Default: a small finance lexicon (no extra dependency, deterministic, transparent).
Optional: set SENTIMENT_BACKEND=vader and `pip install vaderSentiment` to use VADER instead.
This is a deliberately simple baseline, not a state-of-the-art financial sentiment model.
"""
from __future__ import annotations

import os
import re

POSITIVE = {
    "rally", "rallies", "rallied", "surge", "surges", "surged", "soar", "soars", "soared",
    "jump", "jumps", "jumped", "gain", "gains", "gained", "rise", "rises", "rose", "record",
    "strong", "stronger", "beat", "beats", "growth", "profit", "profits", "upgrade", "boost",
    "boosts", "bullish", "recover", "recovers", "recovery", "optimism", "optimistic", "cheer",
    "cheers", "positive", "upbeat", "robust",
}
NEGATIVE = {
    "fall", "falls", "fell", "drop", "drops", "dropped", "crash", "crashes", "plunge", "plunges",
    "plunged", "tumble", "tumbles", "slump", "slumps", "slide", "slides", "loss", "losses",
    "weak", "weaker", "miss", "misses", "cut", "cuts", "downgrade", "bearish", "fear", "fears",
    "selloff", "sell-off", "slowdown", "recession", "war", "tariff", "tariffs", "default", "sink",
    "sinks", "worry", "worries", "concern", "concerns", "risk", "risks", "negative", "turmoil",
}
_TOKEN = re.compile(r"[a-z]+(?:-[a-z]+)?")
_vader = None


def _lexicon_score(text: str) -> float:
    toks = _TOKEN.findall(text.lower())
    pos = sum(t in POSITIVE for t in toks)
    neg = sum(t in NEGATIVE for t in toks)
    return 0.0 if pos + neg == 0 else (pos - neg) / (pos + neg)


def score(text: str) -> float:
    """Return a sentiment score in [-1, 1] for one headline."""
    global _vader
    if os.environ.get("SENTIMENT_BACKEND", "lexicon").lower() == "vader":
        if _vader is None:
            from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
            _vader = SentimentIntensityAnalyzer()
        return float(_vader.polarity_scores(text)["compound"])
    return _lexicon_score(text)
