"""News headline collection.

SOURCES
  1. Google News RSS (primary, no key):
       https://news.google.com/rss/search?q=<query> after:<day> before:<day+1>
     One request per (day, query) lets us rebuild a daily history. Returns up to ~100 items.
  2. NewsAPI (optional, key in $NEWSAPI_KEY) - https://newsapi.org/
     The free plan only reaches back ~1 month, so it is a top-up, not a history source.

Collection is resumable: finished (day, query) pairs are stored in `news_fetch_log`
and skipped on the next run.
"""
from __future__ import annotations

import random
import time
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta, timezone
from email.utils import parsedate_to_datetime

import requests

import config
from src import db, sentiment

IST = timezone(timedelta(hours=5, minutes=30))
GOOGLE_RSS = "https://news.google.com/rss/search"
HEADERS = {"User-Agent": "Mozilla/5.0 (IDC409 student project; contact: see README)"}


def parse_google_rss(xml_text: str, query_name: str, fallback_day: str) -> list[dict]:
    """Turn an RSS document into headline rows (pub_date in IST)."""
    root = ET.fromstring(xml_text)
    rows = []
    for item in root.iter("item"):
        title = (item.findtext("title") or "").strip()
        if not title:
            continue
        src = item.findtext("source") or ""
        if not src and " - " in title:                 # Google appends " - Publisher"
            title, src = title.rsplit(" - ", 1)
        elif src and title.endswith(f" - {src}"):
            title = title[: -len(f" - {src}")]
        try:
            pub = parsedate_to_datetime(item.findtext("pubDate")).astimezone(IST).date().isoformat()
        except Exception:
            pub = fallback_day
        rows.append({
            "pub_date": pub, "query": query_name, "title": title.strip(), "source": src.strip(),
            "link": item.findtext("link") or "", "sentiment": sentiment.score(title),
            "origin": "google_rss",
        })
    return rows


def fetch_google_day(query: str, query_name: str, day: date, timeout: int = 20) -> list[dict]:
    q = f"{query} after:{day.isoformat()} before:{(day + timedelta(days=1)).isoformat()}"
    r = requests.get(GOOGLE_RSS, params={"q": q, "hl": "en-IN", "gl": "IN", "ceid": "IN:en"},
                     headers=HEADERS, timeout=timeout)
    r.raise_for_status()
    return parse_google_rss(r.text, query_name, day.isoformat())


def parse_newsapi(payload: dict, query_name: str) -> list[dict]:
    rows = []
    for a in payload.get("articles", []):
        title = (a.get("title") or "").strip()
        if not title:
            continue
        rows.append({
            "pub_date": (a.get("publishedAt") or "")[:10], "query": query_name, "title": title,
            "source": (a.get("source") or {}).get("name", ""), "link": a.get("url", ""),
            "sentiment": sentiment.score(title), "origin": "newsapi",
        })
    return rows


def fetch_newsapi(query: str, query_name: str, start: date, end: date, key: str) -> list[dict]:
    r = requests.get("https://newsapi.org/v2/everything", params={
        "q": query, "from": start.isoformat(), "to": end.isoformat(), "language": "en",
        "sortBy": "publishedAt", "pageSize": 100, "apiKey": key}, timeout=30)
    r.raise_for_status()
    return parse_newsapi(r.json(), query_name)


def collect_news(conn, days: int = 365, delay: float = 1.0, max_failures: int = 8) -> int:
    """Fetch one query-day at a time, newest first, resuming where we left off."""
    today = date.today()
    done = db.fetched_pairs(conn)
    todo = [(today - timedelta(days=i), qn, q)
            for i in range(1, days + 1) for qn, q in config.NEWS_QUERIES.items()
            if ((today - timedelta(days=i)).isoformat(), qn) not in done]
    print(f"  {len(todo)} query-days to fetch (est. {len(todo) * (delay + 0.4) / 60:.0f} min)")
    added, fails = 0, 0
    for k, (day, qn, q) in enumerate(todo, 1):
        try:
            rows = fetch_google_day(q, qn, day)
            added += db.insert_news(conn, rows)
            db.log_fetch(conn, day.isoformat(), qn, len(rows), "ok")
            fails = 0
        except Exception as e:
            fails += 1
            db.log_fetch(conn, day.isoformat(), qn, 0, f"error: {type(e).__name__}")
            if fails >= max_failures:
                print(f"  [stop] {fails} consecutive failures (last: {e}). Re-run later to resume.")
                break
        if k % 50 == 0:
            print(f"  ... {k}/{len(todo)} done, {added} new headlines")
        time.sleep(delay + random.random() * 0.4)
    if config.NEWSAPI_KEY:                              # optional top-up for the last month
        for qn, q in config.NEWS_QUERIES.items():
            try:
                added += db.insert_news(conn, fetch_newsapi(q, qn, today - timedelta(days=28), today,
                                                            config.NEWSAPI_KEY))
            except Exception as e:
                print(f"  [warn] NewsAPI failed for {qn}: {e}")
    return added
