"""SQLite storage layer: create, read, write (upsert/insert) and modify (update/delete)."""
from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Iterable, Sequence

import pandas as pd

SCHEMA = """
CREATE TABLE IF NOT EXISTS prices (
    date    TEXT NOT NULL,
    symbol  TEXT NOT NULL,          -- short name from config.SYMBOLS
    ticker  TEXT,
    open REAL, high REAL, low REAL, close REAL, volume REAL,
    source  TEXT,                   -- yfinance | alphavantage | synthetic
    PRIMARY KEY (date, symbol)
);
CREATE TABLE IF NOT EXISTS news (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    pub_date  TEXT NOT NULL,        -- IST calendar date
    query     TEXT,
    title     TEXT NOT NULL,
    source    TEXT,
    link      TEXT,
    sentiment REAL,                 -- headline score in [-1, 1]
    origin    TEXT,                 -- google_rss | newsapi | synthetic
    UNIQUE (pub_date, title)
);
CREATE TABLE IF NOT EXISTS news_fetch_log (
    day TEXT NOT NULL, query TEXT NOT NULL, n_items INTEGER, status TEXT,
    PRIMARY KEY (day, query)
);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE INDEX IF NOT EXISTS idx_news_date ON news(pub_date);
"""


def connect(path: str | Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


# ----------------------------- WRITE ---------------------------------------

def upsert_prices(conn: sqlite3.Connection, df: pd.DataFrame) -> int:
    """df columns: date, symbol, ticker, open, high, low, close, volume, source."""
    cols = ["date", "symbol", "ticker", "open", "high", "low", "close", "volume", "source"]
    rows = [tuple(None if pd.isna(v) else v for v in r) for r in df[cols].itertuples(index=False)]
    conn.executemany(
        "INSERT INTO prices(date,symbol,ticker,open,high,low,close,volume,source) "
        "VALUES (?,?,?,?,?,?,?,?,?) "
        "ON CONFLICT(date,symbol) DO UPDATE SET open=excluded.open, high=excluded.high, "
        "low=excluded.low, close=excluded.close, volume=excluded.volume, source=excluded.source",
        rows,
    )
    conn.commit()
    return len(rows)


def insert_news(conn: sqlite3.Connection, rows: Iterable[dict]) -> int:
    """Insert headlines, silently skipping duplicates (same date + title)."""
    before = conn.total_changes
    conn.executemany(
        "INSERT OR IGNORE INTO news(pub_date,query,title,source,link,sentiment,origin) "
        "VALUES (:pub_date,:query,:title,:source,:link,:sentiment,:origin)",
        list(rows),
    )
    conn.commit()
    return conn.total_changes - before


def log_fetch(conn, day: str, query: str, n_items: int, status: str) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO news_fetch_log(day,query,n_items,status) VALUES (?,?,?,?)",
        (day, query, n_items, status),
    )
    conn.commit()


def fetched_pairs(conn) -> set[tuple[str, str]]:
    return {(r["day"], r["query"]) for r in conn.execute(
        "SELECT day, query FROM news_fetch_log WHERE status='ok'")}


def set_meta(conn, key: str, value: str) -> None:
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES (?,?)", (key, str(value)))
    conn.commit()


def get_meta(conn, key: str, default: str = "") -> str:
    r = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    return r["value"] if r else default


def write_table(conn, df: pd.DataFrame, name: str) -> None:
    """Replace a derived table (e.g. the engineered `daily` table)."""
    df.to_sql(name, conn, if_exists="replace", index=False)
    conn.commit()


# ----------------------------- READ ----------------------------------------

def read(conn, sql: str, params: Sequence = ()) -> pd.DataFrame:
    return pd.read_sql_query(sql, conn, params=params)


# ---------------------------- MODIFY ---------------------------------------

def update_close(conn, date: str, symbol: str, new_close: float) -> int:
    """Correct a single bad tick."""
    cur = conn.execute("UPDATE prices SET close=? WHERE date=? AND symbol=?", (new_close, date, symbol))
    conn.commit()
    return cur.rowcount


def delete_where(conn, table: str, where: str, params: Sequence = ()) -> int:
    """Delete rows matching `where` (table name must be one of ours)."""
    if table not in {"prices", "news", "news_fetch_log", "meta"}:
        raise ValueError(f"refusing to delete from unknown table {table!r}")
    cur = conn.execute(f"DELETE FROM {table} WHERE {where}", tuple(params))
    conn.commit()
    return cur.rowcount
