"""SYNTHETIC data generator for offline demo / testing.

!!! Everything produced here is FAKE. It exists only so the pipeline, notebooks and tests can run
!!! without internet. Do not report any result from it as a finding about real markets.

Design: market returns follow a GARCH-like volatility process; peers/commodities/FX are noisy
functions of a market factor. Headlines are template sentences whose keywords react to the SAME
day's moves (news follows the market, like real life) - there is deliberately NO next-day signal
planted anywhere, so honest models should NOT beat a naive baseline by much on this data.
"""
from __future__ import annotations

from datetime import date

import numpy as np
import pandas as pd

import config
from src import db, sentiment

# phrase pools; every phrase contains words that the KEYWORDS regexes / sentiment lexicon recognise
UP = ["Sensex and Nifty rally on strong buying", "Markets surge as banks gain", "Nifty hits record high",
      "Stocks jump on optimism over earnings", "IT stocks gain as software demand recovers"]
DOWN = ["Sensex and Nifty tumble in heavy selloff", "Markets plunge as fears of recession grow",
        "Nifty slides as banks drop", "Stocks crash on weak global cues", "IT stocks slump on tariff worries"]
FLAT = ["Markets trade in narrow range ahead of RBI policy", "Nifty ends flat amid mixed earnings",
        "Investors await Fed commentary", "Budget talk keeps Dalal Street cautious"]
TOPIC = {
    "gold": ["Gold prices edge higher on safe-haven demand", "Gold slips as dollar strengthens"],
    "crude": ["Crude oil climbs on OPEC supply cut", "Brent crude falls as demand worries mount"],
    "petrol": ["Petrol and diesel prices unchanged across metros", "Fuel demand rises in festive season"],
    "rupee": ["Rupee weakens past key level against dollar", "Rupee gains as foreign investor inflows return"],
    "fii": ["FII outflows continue for third session", "FPI buying lifts banking shares"],
    "rbi": ["RBI governor signals cautious stance on repo rate", "Reserve Bank keeps rates steady"],
    "inflation": ["CPI inflation cools to multi-month low", "Inflation worries return as food prices rise"],
    "fed": ["Fed chair Powell hints at rate cut", "Federal Reserve minutes spark volatility"],
    "tariff": ["Trump tariff threat rattles exporters", "Trade deal hopes lift market mood"],
    "war": ["Geopolitical conflict keeps investors on edge", "War fears push safe-haven flows"],
    "gdp": ["India GDP data beats estimates on economic growth", "Economic growth outlook trimmed"],
    "ipo": ["IPO market buzzes with new listings", "Mega IPO opens for subscription"],
    "profit": ["Net profit jumps for largest private lender", "Profit misses estimates for IT major"],
    "election": ["Election outcome in focus for markets", "Polls point to policy continuity"],
}
FILLER = ["Analysts weigh outlook for the week", "Corporate India braces for festive demand",
          "Why small caps are in focus", "How mutual fund inflows are shaping the market",
          "Experts share stock picks for the session", "Quarterly results season kicks off"]


def make_prices(dates: pd.DatetimeIndex, rng: np.random.Generator) -> pd.DataFrame:
    n = len(dates)
    # GARCH(1,1)-style market factor, annualised vol ~ 14%
    omega, alpha, beta = 0.04, 0.08, 0.90
    sig2 = np.empty(n); m = np.empty(n); sig2[0] = 0.8
    for t in range(n):
        if t:
            sig2[t] = omega + alpha * m[t - 1] ** 2 + beta * sig2[t - 1]
        m[t] = np.sqrt(sig2[t]) * rng.standard_t(6) / np.sqrt(6 / 4)
    spec = {   # name: (beta to market, idio vol %, start level, drift %/day)
        "NSEI": (1.0, 0.15, 24000, 0.03), "BSESN": (0.98, 0.18, 79000, 0.03),
        "RELIANCE": (1.0, 1.0, 1400, 0.02), "TCS": (0.7, 1.1, 3800, 0.01),
        "HDFCBANK": (1.1, 0.9, 1700, 0.03), "INFY": (0.8, 1.2, 1700, 0.01),
        "GOLD": (-0.05, 0.9, 2650, 0.03), "PETROL": (0.1, 1.8, 2.1, 0.0),
        "BRENT": (0.15, 1.7, 74, 0.0), "USDINR": (-0.12, 0.18, 84, 0.01),
        "EURINR": (-0.08, 0.45, 91, 0.01),
    }
    petrol_noise = rng.normal(0, 1, n)
    rows = []
    for name, (b, iv, lvl, drift) in spec.items():
        idio = rng.normal(0, iv, n)
        if name == "BRENT":
            idio = 0.8 * petrol_noise * 1.8 + 0.6 * rng.normal(0, 1.0, n)
        if name == "PETROL":
            idio = petrol_noise * iv
        r = drift + b * m + idio
        close = lvl * np.cumprod(1 + r / 100)
        prev = np.r_[lvl, close[:-1]]
        open_ = prev * (1 + rng.normal(0, iv / 3, n) / 100)
        rng_pct = np.abs(rng.normal(0, 0.5 + iv / 2, n)) / 100
        high = np.maximum(open_, close) * (1 + rng_pct)
        low = np.minimum(open_, close) * (1 - rng_pct)
        ticker = config.SYMBOLS[name][0]
        for i, dt in enumerate(dates):
            rows.append((dt.strftime("%Y-%m-%d"), name, ticker, open_[i], high[i], low[i], close[i],
                         float(rng.integers(1e6, 5e6)), "synthetic"))
    return pd.DataFrame(rows, columns=["date", "symbol", "ticker", "open", "high", "low", "close",
                                       "volume", "source"])


def make_news(prices: pd.DataFrame, rng: np.random.Generator) -> list[dict]:
    piv = prices.pivot(index="date", columns="symbol", values="close")
    ret = piv.pct_change().fillna(0) * 100
    rows = []
    for dstr in piv.index:
        r = ret.loc[dstr]
        mkt, size = r["NSEI"], min(abs(r["NSEI"]) / 1.5, 2.0)
        n = rng.poisson(55)
        # topic probabilities react to the same day's moves of the relevant asset
        p = {k: 0.04 for k in TOPIC}
        p["gold"] += 0.10 * min(abs(r["GOLD"]), 3); p["crude"] += 0.08 * min(abs(r["BRENT"]), 3)
        p["petrol"] += 0.05 * min(abs(r["PETROL"]), 3); p["rupee"] += 0.5 * min(abs(r["USDINR"]), 1)
        for i in range(n):
            u = rng.random()
            if u < 0.10 + 0.05 * size:                      # market headline matching direction
                pool = UP if mkt > 0.15 else DOWN if mkt < -0.15 else FLAT
                if rng.random() < 0.40:
                    pool = UP + DOWN + FLAT                  # some noise
                title = rng.choice(pool)
            elif u < 0.75:
                k = rng.choice(list(TOPIC))
                title = rng.choice(TOPIC[k]) if rng.random() < min(1, p[k] * 6) else rng.choice(FILLER)
            else:
                title = rng.choice(FILLER)
            title = f"{title} ({dstr[5:]}-{i})"             # make titles unique per day
            rows.append({"pub_date": dstr, "query": "market", "title": title, "source": "synthetic",
                         "link": f"demo://{dstr}/{i}", "sentiment": sentiment.score(title),
                         "origin": "synthetic"})
    return rows


def populate(conn, end: date | None = None, n_days: int = 520, seed: int = 409) -> None:
    rng = np.random.default_rng(seed)
    end = end or date(2026, 10, 22)
    dates = pd.bdate_range(end=end, periods=n_days)
    prices = make_prices(dates, rng)
    db.upsert_prices(conn, prices)
    db.insert_news(conn, make_news(prices, rng))
    db.set_meta(conn, "data_source", "synthetic")
