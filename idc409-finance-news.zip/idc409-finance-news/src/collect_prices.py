"""Price / commodity / currency collection.

SOURCES
  1. yfinance (primary)  - https://ranaroussi.github.io/yfinance/  (unofficial Yahoo Finance wrapper)
  2. Alpha Vantage (optional fallback, needs free key in $ALPHAVANTAGE_KEY) - https://www.alphavantage.co/
     Only FX_DAILY and TIME_SERIES_DAILY are wired up; futures (gold, RBOB) have no AV fallback.
"""
from __future__ import annotations

import time
from datetime import date, timedelta

import pandas as pd
import requests

import config
from src import db

COLS = ["date", "symbol", "ticker", "open", "high", "low", "close", "volume", "source"]


def _empty() -> pd.DataFrame:
    return pd.DataFrame(columns=COLS)


# ------------------------------ yfinance -----------------------------------

def fetch_yfinance(name: str, ticker: str, start: date, end: date, retries: int = 3) -> pd.DataFrame:
    import yfinance as yf  # imported lazily so demo mode needs no network libs

    last_err = None
    for attempt in range(retries):
        try:
            h = yf.Ticker(ticker).history(start=start.isoformat(), end=end.isoformat(),
                                          interval="1d", auto_adjust=False)
            if h is None or h.empty:
                raise RuntimeError("empty response")
            h = h.reset_index()
            dt = pd.to_datetime(h["Date"])
            if getattr(dt.dt, "tz", None) is not None:
                dt = dt.dt.tz_localize(None)          # keep the exchange-local calendar date
            out = pd.DataFrame({
                "date": dt.dt.strftime("%Y-%m-%d"), "symbol": name, "ticker": ticker,
                "open": h["Open"], "high": h["High"], "low": h["Low"], "close": h["Close"],
                "volume": h.get("Volume", 0.0), "source": "yfinance",
            })
            return out[COLS]
        except Exception as e:                         # network hiccup, rate limit, bad ticker
            last_err = e
            time.sleep(2 * (attempt + 1))
    print(f"  [warn] yfinance failed for {name} ({ticker}): {last_err}")
    return _empty()


# ---------------------------- Alpha Vantage ---------------------------------

def parse_alphavantage(name: str, ticker: str, payload: dict) -> pd.DataFrame:
    """Parse TIME_SERIES_DAILY or FX_DAILY JSON into our price schema."""
    key = next((k for k in payload if k.startswith("Time Series")), None)
    if key is None:
        return _empty()
    rows = []
    for d, v in payload[key].items():
        rows.append({
            "date": d, "symbol": name, "ticker": ticker,
            "open": float(v["1. open"]), "high": float(v["2. high"]),
            "low": float(v["3. low"]), "close": float(v["4. close"]),
            "volume": float(v.get("5. volume", 0.0)), "source": "alphavantage",
        })
    return pd.DataFrame(rows, columns=COLS).sort_values("date").reset_index(drop=True)


def fetch_alphavantage(name: str, kind: str, ticker: str, key: str) -> pd.DataFrame:
    """kind: 'equity' (ticker like RELIANCE.BSE) or 'fx' (ticker like 'USD/INR')."""
    if kind == "fx":
        frm, to = ticker.split("/")
        params = {"function": "FX_DAILY", "from_symbol": frm, "to_symbol": to, "outputsize": "full"}
    else:
        params = {"function": "TIME_SERIES_DAILY", "symbol": ticker, "outputsize": "full"}
    params["apikey"] = key
    r = requests.get("https://www.alphavantage.co/query", params=params, timeout=30)
    r.raise_for_status()
    return parse_alphavantage(name, ticker, r.json())


# -------------------------------- driver ------------------------------------

def collect_prices(conn, years: float = 2.0, symbols: dict | None = None) -> int:
    symbols = symbols or config.SYMBOLS
    end = date.today() + timedelta(days=1)
    start = end - timedelta(days=int(365 * years))
    total = 0
    for name, (ticker, _cat, _note) in symbols.items():
        df = fetch_yfinance(name, ticker, start, end)
        if df.empty and config.ALPHAVANTAGE_KEY and name in {"USDINR", "EURINR"}:
            df = fetch_alphavantage(name, "fx", f"{name[:3]}/{name[3:]}", config.ALPHAVANTAGE_KEY)
        n = db.upsert_prices(conn, df) if not df.empty else 0
        print(f"  {name:9s} {ticker:12s} {n:5d} rows")
        total += n
    return total
