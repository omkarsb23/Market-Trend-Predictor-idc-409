"""Turn raw `prices` + `news` tables into one modelling table (one row per NSE trading day).

TIMING / LEAKAGE RULES (important - this is what makes the evaluation honest)
  * Row `t` is "what we know just before the market opens on the NEXT trading day".
  * Other assets (gold, petrol, FX ...) are aligned as-of: for NSE date t we use the latest
    close dated <= t. US futures close after NSE does, but still before the next NSE open.
  * Headlines are assigned to the first trading day >= their date, so a Saturday story lands in
    Monday's row, never in Friday's. This is conservative: no headline from the target day is used.
  * Targets look one trading day ahead: next-day return (%), direction, absolute move.
"""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd

import config
from src import db


# --------------------------------------------------------------------------- prices
def _rsi(close: pd.Series, n: int = 14) -> pd.Series:
    delta = close.diff()
    up = delta.clip(lower=0).rolling(n).mean()
    down = (-delta.clip(upper=0)).rolling(n).mean()
    rs = up / down.replace(0, np.nan)
    return 100 - 100 / (1 + rs)


def build_price_features(conn) -> pd.DataFrame:
    prices = db.read(conn, "SELECT date, symbol, high, low, close FROM prices "
                           "WHERE close IS NOT NULL AND close > 0")
    if prices.empty:
        raise RuntimeError("No prices in database - run the price collector first.")
    prices = prices.drop_duplicates(["date", "symbol"])
    prices["date"] = pd.to_datetime(prices["date"])
    close = prices.pivot(index="date", columns="symbol", values="close").sort_index()
    if config.TARGET not in close:
        raise RuntimeError(f"Target series {config.TARGET} missing from prices table.")

    spine = close[config.TARGET].dropna().index                 # NSE trading days
    aligned = close.reindex(close.index.union(spine)).ffill().reindex(spine)   # as-of join
    rets = aligned.pct_change() * 100

    d = pd.DataFrame(index=spine)
    c = aligned[config.TARGET]
    d["close"] = c
    d["ret"] = rets[config.TARGET]
    for k in range(1, 5):
        d[f"ret_lag{k}"] = d["ret"].shift(k)
    ma5, ma20 = c.rolling(5).mean(), c.rolling(20).mean()
    d["ma5_gap"] = (c / ma5 - 1) * 100
    d["ma20_gap"] = (c / ma20 - 1) * 100
    d["ma5_ma20"] = (ma5 / ma20 - 1) * 100
    d["vol5"] = d["ret"].rolling(5).std()
    d["vol20"] = d["ret"].rolling(20).std()
    d["rsi14"] = _rsi(c)
    hi = prices[prices.symbol == config.TARGET].set_index("date")["high"].reindex(spine)
    lo = prices[prices.symbol == config.TARGET].set_index("date")["low"].reindex(spine)
    d["hl_range"] = (hi - lo) / c * 100

    for n in config.PEERS + config.MACRO:
        if n in aligned:
            d[f"{n}_ret"] = rets[n]
    for n in config.MACRO:
        if n in aligned:
            d[f"{n}_ret_lag1"] = rets[n].shift(1)
    for n in aligned.columns:                                   # raw levels, for EDA plots
        if n != config.TARGET:
            d[f"{n}_close"] = aligned[n]
    return d


# --------------------------------------------------------------------------- news
def build_news_features(conn, spine: pd.DatetimeIndex) -> pd.DataFrame:
    news = db.read(conn, "SELECT pub_date, title, sentiment FROM news")
    cols = (["n_headlines", "sentiment_mean", "sentiment_3d", "neg_share"]
            + [f"kw_{k}" for k in config.KEYWORDS] + [f"kwr_{k}" for k in config.KEYWORDS])
    if news.empty:
        print("  [warn] no news rows; news features will be zero.")
        return pd.DataFrame(0.0, index=spine, columns=cols)

    news["pub_date"] = pd.to_datetime(news["pub_date"])
    news = news[news["pub_date"] <= spine[-1]]
    pos = np.searchsorted(spine.values, news["pub_date"].values)  # first trading day >= date
    news["day"] = spine[pos]
    for k, pat in config.KEYWORDS.items():
        news[f"kw_{k}"] = news["title"].str.contains(re.compile(pat, re.I)).astype(int)
    news["neg"] = (news["sentiment"] < 0).astype(int)

    g = news.groupby("day")
    out = pd.DataFrame({"n_headlines": g.size(), "sentiment_mean": g["sentiment"].mean(),
                        "neg_share": g["neg"].mean()})
    for k in config.KEYWORDS:
        out[f"kw_{k}"] = g[f"kw_{k}"].sum()
    out = out.reindex(spine)
    out["n_headlines"] = out["n_headlines"].fillna(0)
    out = out.fillna({"sentiment_mean": 0.0, "neg_share": 0.0})
    for k in config.KEYWORDS:
        out[f"kw_{k}"] = out[f"kw_{k}"].fillna(0)
        out[f"kwr_{k}"] = out[f"kw_{k}"] / out["n_headlines"].clip(lower=1)
    out["sentiment_3d"] = out["sentiment_mean"].rolling(3, min_periods=1).mean()
    return out[cols]


# --------------------------------------------------------------------------- assemble
def build_daily(conn) -> pd.DataFrame:
    d = build_price_features(conn)
    d = d.join(build_news_features(conn, d.index))
    d["next_close"] = d["close"].shift(-1)
    d["target_ret"] = d["close"].pct_change().shift(-1) * 100
    d["target_dir"] = np.where(d["target_ret"].isna(), np.nan, (d["target_ret"] > 0).astype(float))
    d["next_abs_ret"] = d["target_ret"].abs()
    d.index.name = "date"
    return d


def feature_groups(columns) -> dict[str, list[str]]:
    cols = list(columns)
    tech = [c for c in ["ret", "ret_lag1", "ret_lag2", "ret_lag3", "ret_lag4", "ma5_gap", "ma20_gap",
                        "ma5_ma20", "vol5", "vol20", "rsi14", "hl_range"] if c in cols]
    others = config.PEERS + config.MACRO
    cross = [c for c in cols if any(c == f"{n}_ret" or c == f"{n}_ret_lag1" for n in others)]
    news = [c for c in ["n_headlines", "sentiment_mean", "sentiment_3d", "neg_share"] if c in cols]
    news += [c for c in cols if c.startswith("kwr_")]
    return {"tech": tech, "cross": cross, "news": news}


def clean(daily: pd.DataFrame) -> tuple[pd.DataFrame, str]:
    """Drop warm-up rows, the final row (no target yet) and impossible ticks; return a report."""
    lines = [f"rows before cleaning: {len(daily)}"]
    g = feature_groups(daily.columns)
    need = g["tech"] + g["cross"] + ["target_ret", "target_dir", "next_close"]
    d = daily.dropna(subset=need)
    lines.append(f"dropped for missing values (indicator warm-up / no next-day target): {len(daily) - len(d)}")
    ret_cols = [c for c in d.columns if c.endswith("_ret") or c == "ret"] + ["target_ret"]
    bad = (d[ret_cols].abs() > 20).any(axis=1)
    lines.append(f"dropped for |daily return| > 20% (treated as bad ticks): {int(bad.sum())}")
    d = d[~bad]
    lines.append(f"rows after cleaning: {len(d)}  ({d.index.min().date()} -> {d.index.max().date()})")
    return d, "\n".join(lines)


def build_and_export(conn, csv_path: Path, report_path: Path | None = None) -> pd.DataFrame:
    daily = build_daily(conn)
    out = daily.reset_index().assign(date=lambda x: x["date"].dt.strftime("%Y-%m-%d"))
    db.write_table(conn, out, "daily")
    clean_df, report = clean(daily)
    clean_df.reset_index().assign(date=lambda x: x["date"].dt.strftime("%Y-%m-%d")) \
        .to_csv(csv_path, index=False, float_format="%.6g")
    if report_path:
        Path(report_path).write_text(report + "\n")
    print("  " + report.replace("\n", "\n  "))
    return clean_df
