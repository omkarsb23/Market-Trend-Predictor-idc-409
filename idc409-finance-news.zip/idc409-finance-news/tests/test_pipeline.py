"""Offline tests (no internet needed).  Run:  python -m pytest -q   or   python tests/test_pipeline.py"""
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config  # noqa: E402
from src import collect_news, collect_prices, db, features, sentiment  # noqa: E402

RSS = """<?xml version="1.0"?><rss><channel>
<item><title>Sensex surges 500 points as banks gain - Economic Times</title>
<link>http://x/1</link><pubDate>Tue, 03 Jun 2025 21:00:00 GMT</pubDate><source url="http://et">Economic Times</source></item>
<item><title>Rupee falls against dollar - Mint</title><link>http://x/2</link>
<pubDate>Tue, 03 Jun 2025 05:00:00 GMT</pubDate><source url="http://m">Mint</source></item>
</channel></rss>"""


def test_rss_parser_strips_publisher_and_converts_to_ist():
    rows = collect_news.parse_google_rss(RSS, "market", "2025-06-03")
    assert rows[0]["title"] == "Sensex surges 500 points as banks gain"
    assert rows[0]["source"] == "Economic Times"
    assert rows[0]["pub_date"] == "2025-06-04"      # 21:00 GMT = 02:30 IST next day
    assert rows[1]["pub_date"] == "2025-06-03"
    assert rows[0]["sentiment"] > 0 > rows[1]["sentiment"]


def test_newsapi_parser():
    rows = collect_news.parse_newsapi({"articles": [
        {"title": "Gold hits record high", "publishedAt": "2025-06-03T10:00:00Z",
         "source": {"name": "X"}, "url": "u"}, {"title": None}]}, "macro")
    assert len(rows) == 1 and rows[0]["pub_date"] == "2025-06-03" and rows[0]["origin"] == "newsapi"


def test_alphavantage_parser_fx_and_equity():
    fx = {"Time Series FX (Daily)": {"2025-06-03": {"1. open": "85.0", "2. high": "85.5",
                                                     "3. low": "84.9", "4. close": "85.2"}}}
    df = collect_prices.parse_alphavantage("USDINR", "USD/INR", fx)
    assert df.loc[0, "close"] == 85.2 and df.loc[0, "volume"] == 0.0
    eq = {"Time Series (Daily)": {"2025-06-02": {"1. open": "1", "2. high": "2", "3. low": "1",
                                                  "4. close": "1.5", "5. volume": "100"}}}
    assert collect_prices.parse_alphavantage("X", "X", eq).loc[0, "volume"] == 100.0
    assert collect_prices.parse_alphavantage("X", "X", {"Note": "rate limit"}).empty


def test_sentiment_sign():
    assert sentiment.score("Markets rally on strong growth") > 0
    assert sentiment.score("Stocks crash amid recession fears") < 0
    assert sentiment.score("Board meets on Tuesday") == 0


def test_db_crud_roundtrip():
    with tempfile.TemporaryDirectory() as t:
        conn = db.connect(Path(t) / "x.db")
        px = pd.DataFrame([["2025-01-01", "NSEI", "^NSEI", 1, 2, 1, 100.0, 5, "t"]],
                          columns=collect_prices.COLS)
        db.upsert_prices(conn, px)
        db.upsert_prices(conn, px.assign(close=101.0))               # upsert, not duplicate
        assert db.read(conn, "SELECT COUNT(*) n FROM prices").n[0] == 1
        assert db.update_close(conn, "2025-01-01", "NSEI", 99.0) == 1
        assert db.read(conn, "SELECT close FROM prices").close[0] == 99.0
        row = dict(pub_date="2025-01-01", query="q", title="t", source="s", link="l", sentiment=0.0, origin="o")
        assert db.insert_news(conn, [row, row]) == 1                   # duplicate skipped
        assert db.delete_where(conn, "news", "pub_date=?", ("2025-01-01",)) == 1
        try:
            db.delete_where(conn, "sqlite_master", "1=1"); raise AssertionError("should refuse")
        except ValueError:
            pass


def _mini_db(tmp):
    conn = db.connect(Path(tmp) / "m.db")
    days = pd.bdate_range("2025-01-01", periods=60)           # Wed 1 Jan 2025 onward
    rng = np.random.default_rng(0)
    rows = []
    for name in ["NSEI", "GOLD"] + [n for n in config.SYMBOLS if n not in ("NSEI", "GOLD")]:
        c = 100 * np.cumprod(1 + rng.normal(0, .01, len(days)))
        for dt, v in zip(days, c):
            if name == "GOLD" and dt == days[10]:
                continue                                       # gold holiday -> as-of join must ffill
            rows.append((dt.strftime("%Y-%m-%d"), name, name, v, v * 1.01, v * .99, v, 1.0, "t"))
    db.upsert_prices(conn, pd.DataFrame(rows, columns=collect_prices.COLS))
    return conn, days


def test_targets_and_no_lookahead():
    with tempfile.TemporaryDirectory() as t:
        conn, days = _mini_db(t)
        d = features.build_daily(conn)
        close = d["close"]
        i = 30
        assert np.isclose(d["target_ret"].iloc[i], (close.iloc[i + 1] / close.iloc[i] - 1) * 100)
        assert np.isclose(d["ret"].iloc[i], (close.iloc[i] / close.iloc[i - 1] - 1) * 100)
        assert np.isnan(d["target_ret"].iloc[-1])              # last row has no future
        # features at row i must not change if we corrupt all FUTURE prices
        conn.execute("UPDATE prices SET close = close*3 WHERE date > ?", (days[i].strftime("%Y-%m-%d"),))
        d2 = features.build_daily(conn)
        feats = features.feature_groups(d.columns)
        cols = feats["tech"] + feats["cross"]
        pd.testing.assert_series_equal(d.loc[days[i], cols], d2.loc[days[i], cols], check_names=False)
        # gold holiday: aligned return that day is 0 (stale close), not a duplicated earlier return
        assert d["GOLD_ret"].loc[days[10]] == 0.0 or abs(d["GOLD_ret"].loc[days[10]]) < 1e-12


def test_weekend_news_goes_to_next_trading_day_only():
    with tempfile.TemporaryDirectory() as t:
        conn, days = _mini_db(t)
        fri = [x for x in days if x.weekday() == 4][2]
        sat, mon = fri + pd.Timedelta(days=1), fri + pd.Timedelta(days=3)
        base = dict(query="q", source="s", link="l", sentiment=0.5, origin="t")
        db.insert_news(conn, [dict(base, pub_date=sat.strftime("%Y-%m-%d"), title="Gold rally on Saturday"),
                              dict(base, pub_date=fri.strftime("%Y-%m-%d"), title="Gold slips Friday")])
        d = features.build_daily(conn)
        assert d.loc[fri, "n_headlines"] == 1 and d.loc[mon, "n_headlines"] == 1
        assert d.loc[mon, "kw_gold"] == 1 and d.loc[fri, "kw_gold"] == 1
        assert d.loc[fri, "kw_rally"] == 0                      # Saturday's "rally" not in Friday's row


def test_demo_pipeline_builds_clean_csv():
    with tempfile.TemporaryDirectory() as t:
        from src import demo_data
        conn = db.connect(Path(t) / "d.db")
        demo_data.populate(conn, n_days=120)
        df = features.build_and_export(conn, Path(t) / "out.csv")
        assert len(df) > 80 and df["target_dir"].isin([0, 1]).all()
        assert not df[features.feature_groups(df.columns)["tech"]].isna().any().any()


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for f in fns:
        f(); print("PASS", f.__name__)
    print(f"{len(fns)} tests passed")
